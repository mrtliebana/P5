// Adaptado de "Learning Processing" por Daniel Shiffman
// learningprocessing.com
let input;
let analyzer;

function preload(){
  img = loadImage('sonar.png');
}

//function preload(
 //img = loadImage ("sonar.png");
//)

function setup() {
  createCanvas(420, 600);
  background(255);

  // crea una entrada de audio
  input = new p5.AudioIn();
 textFont("Lato");
 textSize(50);
  input.start();
}




function draw() {
  
  
  // volumen (entre 0.0 y 1.0)
  let volume = input.getLevel();

  // si volume > 0.1,  se dibuja un rectángulo en una posición aleatoria.
  // a mayor volumen, más grande el rectángulo.

  let threshold = 0.01;
  
  if (volume > threshold) {
    
    stroke(0,27,177);
    fill(0,27,177);
    rect(random(40, width), random(height), volume * 50, volume * 50);
    fill(255);
    stroke(255);
    strokeWeight(5);
    text('PEGGY GOU', width/2, height/2);
    text('sónar', width/2, height/3);
    textAlign(CENTER, CENTER);
    

  }

}








